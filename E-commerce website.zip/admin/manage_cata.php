
<?php 
    $views = "manage-cata";
    include ("template.php");

?>