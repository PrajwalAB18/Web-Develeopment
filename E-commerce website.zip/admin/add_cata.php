<?php 
    $views = "add-cata";
    include ("template.php");

?>