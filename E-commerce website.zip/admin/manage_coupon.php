<?php 
    $views = "manage_coupon";
    include ("template.php");

?>