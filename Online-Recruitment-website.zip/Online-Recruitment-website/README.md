<h1 align = 'center'>Recruitment-Portal</h1>
<img align="right" width="300" height="300" src="https://upload.wikimedia.org/wikipedia/en/4/43/Indian_Institute_of_Information_Technology%2C_Nagpur.png" >

[![forthebadge](https://img.shields.io/badge/USES-PHP-orange)](http://forthebadge.com)
[![forthebadge](https://img.shields.io/badge/USES-HTML-red)](http://forthebadge.com)

## About

This is a faculty Recruitment-Portal of Indian Institute of Information Technology, Nagpur.
It will help people to directly get in touch with institute skipping the load of paper work.

## Get in touch
[<img src="https://upload.wikimedia.org/wikipedia/en/4/43/Indian_Institute_of_Information_Technology%2C_Nagpur.png" width="35" padding="10">](https://iiitn.ac.in/)
[<img src="https://upload.wikimedia.org/wikipedia/commons/9/91/Octicons-mark-github.svg" width="35" padding="10">](https://github.com/iiit-nagpur)
- 
-
